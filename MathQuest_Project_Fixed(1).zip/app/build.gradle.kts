plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.mathquest.app"
    compileSdk = 36
    defaultConfig {
        applicationId = "com.mathquest.app"
        minSdk = 23
        targetSdk = 35
        versionCode = 2
        versionName = "1.1"
    }
}

dependencies {
    implementation("androidx.activity:activity-ktx:1.10.1")
}
