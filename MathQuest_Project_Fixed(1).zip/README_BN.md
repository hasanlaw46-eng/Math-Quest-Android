# Math Quest 1.1
- ১০,০০০টি গণিত Level
- Player name, profile picture ও cover picture
- Achievement display
- Manual progress backup/restore code
- WebView file chooser সীমিতভাবে image picker-এ ব্যবহৃত
- Internet permission নেই; profile/progress ডিভাইসেই থাকে

নোট: এটি offline local profile। LocalStorage-এ থাকা স্কোর/প্রগ্রেস ডিভাইসের মালিক পরিবর্তন করতে পারে; অনলাইন leaderboard বা tamper-proof score নয়।
