# Math Quest 1.2 — Android Project

Features: 10,000 generated levels; arithmetic, algebra, geometry and mixed practice; Bengali/English selector; local player profile with avatar and cover; score, progress, attempts, correct answers, success rate and recent history; optional sound and color effects; backup/restore; offline-first WebView app without network permission.

Build: Upload this ZIP to the repository root as `MathQuest_Project_Fixed(1).zip`. Add `.github/workflows/build-apk.yml` from this project, commit to `main`, then open Actions and download the `Math-Quest-APK` artifact after a successful run.

The debug APK is for testing. Google Play publishing requires a signed Android App Bundle (AAB), store listing and policy review. A minor must have an adult legally manage the Play Console account.

Security: Profile and progress are stored locally. Backup codes contain that data; keep them private. Offline local data is not tamper-proof. Do not enter passwords or sensitive personal information.
